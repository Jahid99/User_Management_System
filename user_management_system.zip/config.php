<?php
return [
	'client-key' => '6Ldx9DEUAAAAAEsmNhqrpFG-GdgkB26_uAgie7mZ',
	'secret-key' => '6Ldx9DEUAAAAAGslstkJNvL6FLl2PJP80tqSeGY5'
];
