
</div>
<div id="footer">
    <footer id="footer" class="midnight-blue">
        <div class="container">
            <div class="row">
                <div class="col-sm-12"><center>
                    Copyright &copy; 2018 All rights reserved</center>
                </div>
            </div>
        </div>
    </footer><!--/#footer-->
</div>

    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/main.js"></script>
    </div>
</body>
</html>