         </div>
     </div>
  </div><!-- #content -->
    <div id="footer">
        <div class="container">
        
          <hr>
        <p class="centered">Copyright &copy; 2018 All rights reserved</p>
        </div>
    </div>
 
    </div>
</div>

    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="<?php echo SITE_URL;?>assets/js/bootstrap.min.js"></script>
  </body>
</html>
