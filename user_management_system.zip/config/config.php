<?php
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "user_management_system");
define("SITE_URL", "http://localhost/user_management_system/");